# Propositions de logo du Clover Launcher

Quatre trèfles à quatre feuilles générés pour la demande du 2026-10-05 : silhouette large,
contours en pixels et tige courte. Vert de référence du launcher : `#52A96C`, confirmé dans
`src/styles.css` et `design/README.md`. Les rendus comprennent des nuances de ce vert.

| Fichier | Direction | Fond |
| --- | --- | --- |
| `01-classic.png` | Trèfle classique, contour sombre et reflets | Transparent |
| `02-block.png` | Forme compacte avec tranche en relief façon bloc Minecraft | Transparent |
| `03-geometric.png` | Silhouette simplifiée | Sombre, inspiré de `#14120F` |
| `04-retro.png` | Quatre feuilles en forme de cœur orientées en losange | Transparent |

Dimensions vérifiées : **1254 × 1254 pixels** pour chaque PNG. Les trois fonds transparents
possèdent un canal alpha ; la version géométrique a été refaite sur fond sombre après un
détourage défectueux. Les dimensions, tailles et propriétés alpha sont dans `metadata.json`.

Préférence proposée : **02-block**, pour sa compacité et son relief cohérent avec Minecraft.
Les assets actuels du launcher sont conservés ; la proposition choisie pourra ensuite être
préparée pour les différentes tailles d'icônes du launcher.
